
<?php
include("connection.php");

 echo $_SESSION['longitude'];
$_SESSION['cstvaluee']=$_REQUEST['cstvaluee'];

// echo "<pre>"; 
// print_r($_GET);
// echo "<pre>"; 


// echo $_GET['cstvaluee'];
// $variable = $_GET['cstvaluee'];
// echo "<pre>"; 
// echo $_GET['longitude']; 

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roof Angle</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</head>
<body>
    <script>
    $(document).ready(function(){
//       $("#1").click(function(){
//      let btn1 = document.getElementById("roof_change");
//       let val = btn1.value;
//       document.getElementById("result").innerHTML = val ;
      

//   });
//   $("#btn_roof2").click(function(){
//       $("#box2").show();
//       $("#box1").hide();
//       $("#box3").hide();
     

//   });
//   $("#btn_roof3").click(function(){
//       $("#box3").show();
//       $("#box1").hide();
//       $("#box2").hide();
      


//   });

  $(document).on('click','.roof_change' ,function(){
      
           $('.roof_change').removeClass("active");
           $(this).addClass('active');
           $(".boxing").hide();
           
           var id=$(this).attr('id');
           var name=$(this).data('name');
           $("#box"+id).show();
      });


});

    </script>
    <style>
        * {
        margin: 0;
        padding: 0;
        }

        html,
      body {
        font-family: 'Montserrat', sans-serif;
      }
     
      .container {
        display: flex;
        justify-content: space-around;
        margin-top: 50px;
      }
      #box1 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         /* display: none; */
      }
      #box2 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         /* display: none; */
      }
      #box3 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         /* display: none; */
      }
      img {
        width: 100%;
        height: 605px;
        border-radius: 10px 0px 0px 10px;
      }
      .box2 {
        display: flex;
        flex-direction: column;
        align-items: start;
        padding: 0px 0 0 30px;
        width: 50%;
        position: absolute;
        right: -59px;
      }
      .class {
        margin: 15px 0px 10px  0;
        width:520px;
        align-items: center;
      }

      .class1 {
        margin-top: 125px;
        font-size:28px;
      }
     

      #vul {
        font-size: 15px;
      }

      #btn_submit{
        padding: 14px 46px 14px 46px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #0e0d12;
    margin-top: 80px;
    margin-right: -124px;
    position: absolute;
    right: 547px;
    bottom: -180px;
      }

      #btn1_submit{
        padding: 14px 46px 14px 46px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #bdbac3;
    margin-top: 130px;
    position: absolute;
    left: 48px;
    text-decoration:none;


      }

      #btn_submit:hover {
        background-color: rgb(48, 78, 124);
        transition-duration: 0.8s;
        color: white;
      }

      #btn1_submit:hover {
        background-color: rgb(48, 78, 124);
        transition-duration: 0.8s;
        color: white;
      }
      #btn{
        display: flex;
        justify-content: space-around;
      }
      input{
        margin: 8px 0px 8px 0;
    border: none;
    padding: 18px 215px 18px 20px;
        font-size: 15px;
        /* border: 1px solid black;
         */
         background-color:#f7f7f7;
         color:black;
        cursor: pointer;
        
      }
      input.active {
        background-color:black;
        color:white;
      }
    </style>
<!-- <div method = "get" class="cost">
  <p id ="value" ><?php echo $_GET['cstvaluee'];?></p>
  <input type="text" id ="threetofour" value="<?php echo $_GET['cstvaluee'];?>" >
</div> -->

<div class="container">
      <div id="box1" class="boxing">
        <img src="image/roof3.png" alt="" />
      </div>
      <div id="box2" class="boxing">
        <img src="image/roof2.png" alt="" />
      </div>
      <div id="box3" class="boxing">
        <img src="image/roof1.png" alt="" />
      </div>
       
      <div class="box2">
        <p class="class1">Hoe schat je de hellingshoek van jouw dak in?</p>
        <p id="vul" class="class">
        Als we de hellingsgraad weten, kunnen we beter inschatten hoe de zon op je dak schijnt.
      </p>
      <input type="button" value="Plat dek               0-15°" data-name="Plat dek" id="1" class="roof_change active" name="save" selected />
      <input type="Submit" value="Schuin dak        15-30°" data-name="Schuin dak" id="2" class="roof_change" name="save" />
      <input type="Submit" value="Steil dak               30° >" data-name="Steil dak" id="3" class="roof_change" name="save"  />

      <form action="testing4.php" method="get">
      <input type="hidden" id ="thhidd" value="<?php echo $_GET['cstvaluee'];?>" name="cst_val">
      <input type="hidden" id ="fourthh" value="<?php echo $_GET['totalcost'];?>" name="totalcost_val">
      <input type="hidden" id ="fourthh" value="<?php echo $_GET['select_area'];?>" name="select_land_area">
          <div id="btn">
          <!-- <input type="text" id="cstvaluee" name="cstvaluee"> -->
            <input type="Submit" value="Next" id="btn_submit" name="save" />
            </div>
          </form>
      <div>
        <!--<form action="testing2.php" method="get">-->
          <div id="btn">
            <!--<input type="Submit" value="Back" id="btn1_submit" name="save" />-->
            <a href="https://googlemap.tentoptoday.com/testing2.php?address=Cyber+Vision+Infotech+Pvt+Ltd+%28formerly+CV+Infotech%29%2C+Udyog+Vihar+Phase+V%2C+Udyog+Vihar%2C+Sector+19%2C+Gurugram%2C+Haryana%2C+India&latitude=28.49961759999999&longitude=77.0835913&save=Start" id="btn1_submit" >Back</a>
            </div>
          <!--</form>-->
        </div>
        </div>
        </div>
      </div>
    </div>
</body>
</html>