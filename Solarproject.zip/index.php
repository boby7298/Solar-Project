<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Geocodes</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  </head>
  <body>
    <!DOCTYPE html>
    <html>
      <head>
        <title>
          Get latitude and longitude from address google map api javascript
        </title>
        <style>
          #latitude{
            display:none;
          }
          #longitude{
            display:none;
          }

          *{
        margin: 0;
        padding: 0;
      }
      
      html,
      body {
        font-family: 'Montserrat', sans-serif;
        background-color:#f7f7f7;
      }
      .container {
        display: flex;
        justify-content: space-around;
       position:absolute;
        top:18%;
        left:21%;
        background-color:#ffffff;
        border-radius: 0px 10px 10px 0px;


      }
      #box1 {
        /* width: 50%;
        /* height: 400px; */ */
        border-radius: 10px 0 0 10px;
        /* position: absolute;
        left: 0px;
        margin-left: 20px; */
      }
      img {
        width: 100%;
        height: 605px;
        border-radius: 10px 0px 0px 10px;
      }
      .box2 {
        display: flex;
    flex-direction: column;
    align-items: start;
    margin-left:25px;

      }
      .class {
        margin: 20px 20px 20px 0;
        font-size:17px;
        width: 490px;
      }
      .class1 {
        margin-top: 215px;
        font-size:28px;
      }
      #address{
            padding: 0px 10px 0px 10px;
    font-size: 15px;
    border-radius: 20px;
    border: 1px solid black;
    cursor: pointer;
    width: 485px;
    height: 45px;
      }

      #vul {
        font-size: 17px;
      }

      #btn_submit{
        padding: 14px 56px 14px 27px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #0e0d12;
    margin-top: 165px;
    margin-left: 356px;
   
      }

      #btn_submit:hover {
        background-color: rgb(48, 78, 124);
        transition-duration: 0.8s;
        color: white;
      }
      i{
        color: white;
    /* margin-left: 85px; */
    position: absolute;
    left: 437px;
    bottom: -195px;
      }
          #addressw{
        display:flex;
        justify-content:start;
      }
      #address1{
        font-size: 20px;
    margin: 0 10px 15px 0;
    font-weight: 600;
      }
      #address2{
        margin-top:3px;
    
      }

        </style>
      </head>
      <body>
        <div class="container">
      <div id="box1">
        <img src="image/roof.png" alt="" />
      </div>
       
      <div class="box2">
               <form action="testing2.php" method="get">
        <p class="class1">Check de mogelijkheden op je dak</p>
        <p id="vul" class="class">
          Vul hieronder je adres in, bereken je dakmaten en bekijk hoeveel je
          kan besparen.
        </p>
         <div id="addressw">
          <p id="address1">Address:</p>
          <p id="address2">Cyber Vision Infotech</p>
        </div>
          <input id="address" name="address" type="text" placeholder="Enter address here" />
          <div>
      
              <input type="text" id="latitude" name="latitude"/>
              <input type="text" id="longitude" name="longitude"/>
              <div class="icon">
         <input type="Submit" value="Start" id="btn_submit" name="save"/>
              <i class="fa-solid fa-arrow-right"></i>
              </div>
            </form>
            </div>
        </div>
        </div>

        <!-- Add the this google map apis to webpage -->
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&key=AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg&libraries=places"></script>

        <script>
          var map9 = "load";
          google.maps.event.addDomListener(window, map9, initialize);
          function initialize() {
            var input = document.getElementById("address");
            var autocomplete = new google.maps.places.Autocomplete(input);
            autocomplete.addListener("place_changed", function () {
              var place = autocomplete.getPlace();
              // place variable will have all the information you are looking for.

              document.getElementById("latitude").value =
                place.geometry["location"].lat();
              document.getElementById("longitude").value =
                place.geometry["location"].lng();
            });
          }
        </script>
      </body>
    </html>
  </body>
</html>
