<?php 


// session_start();

 require("PHPMailer-master/src/PHPMailer.php");
 require("PHPMailer-master/src/SMTP.php");

$servername = "localhost";
$username = "cvinfote_boby";
$password = "Iphone@7298";
$database = "cvinfote_google";

//CONNECTION TO PHP MY ADMIN
$conn = mysqli_connect($servername,$username,$password,$database);
if(!$conn){
  die("Errordetected".mysqli_connect_error());
  
}
else{
  echo "<br>";
}

?>