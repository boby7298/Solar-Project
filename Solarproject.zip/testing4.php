
<?php 
$variable = ($_GET['cst_val']);
$value2 = 1000;
$value1 = 250;
$variable1 = (int)$variable + (int)$value2 ;
$variable2 = (int)$variable + (int)$value1;
$variable_a = ($_GET['totalcost_val']);
$value2a = 35000;
$value1a = 15000;
$variable1a = (int)$variable_a + (int)$value2a ;
$variable2a = (int)$variable_a + (int)$value1a;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roof Angle</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</head>
<body>
    <script>
      $(document).ready(function(){
      $("#btn_roof1").click(function(){
      $("#box1").show();
      $("#box2").hide();
      $("#box3").hide();
  });
  $("#btn_roof2").click(function(){
      $("#box2").show();
      $("#box1").hide();
      $("#box3").hide();
  });
  $("#btn_roof3").click(function(){
      $("#box3").show();
      $("#box1").hide();
      $("#box2").hide();
  });

  $("#btn_roof1").click(function(){
      $("#info_main").show();
      $("#cost1").show();
      $("#info_main1").hide();
      $("#info_main2").hide();
  });
  $("#btn_roof2").click(function(){
      $("#info_main1").show();
      $("#info_main").hide();
      $("#info_main2").hide();
  });
  $("#btn_roof3").click(function(){
      $("#info_main2").show();
      $("#info_main").hide();
      $("#info_main1").hide();
  });

  $("#btn_roof1").click(function(){
      $("#cost1").show();
      $("#cost2").hide();
      $("#cost3").hide();
  });
  $("#btn_roof2").click(function(){
      $("#cost2").show();
      $("#cost1").hide();
      $("#cost3").hide();
  });
  $("#btn_roof3").click(function(){
      $("#cost3").show();
      $("#cost1").hide();
      $("#cost2").hide();
  });
  $("#btn_roof1").click(function(){
      $("#cost1a").show();
      $("#cost2a").hide();
      $("#cost3a").hide();
  });
  $("#btn_roof2").click(function(){
      $("#cost2a").show();
      $("#cost1a").hide();
      $("#cost3a").hide();
  });
  $("#btn_roof3").click(function(){
      $("#cost3a").show();
      $("#cost1a").hide();
      $("#cost2a").hide();
  });

});
      $(document).on('click','input' ,function(){
      $(this).addClass('active').siblings().removeClass('active');
      });


    </script>
    <style>
        * {
        margin: 0;
        padding: 0;
        }
        
        html,
      body {
        font-family: 'Montserrat', sans-serif;
        background-color:#f7f7f7;

      }
     
      .container {
        display: flex;
        justify-content: space-around;
        margin-top: 50px;
        background-color:#FFFFFF;

      }
      #box1 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         /* display: none; */
         background-color: white;
      }
      #box2 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         /* display: none; */
      }
      #box3 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         /* display: none; */
      }
      img {
        width: 100%;
        height: 605px;
        border-radius: 10px 0px 0px 10px;
      }
      .box2 {
        display: flex;
        flex-direction: column;
        align-items: start;
        padding: 0px 0 0 30px;
        width: 50%;
        position: absolute;
        right: -59px;
        background-color: white;
      }
      .class {
        margin: 10px 10px 10px 0;
        width:520px;
        align-items: center;
      }
      .class1 {
        margin-top: 30px;
        font-size:28px;
      }
     

      #vul {
        font-size: 15px;
      }

      #btn_submit{
        padding: 14px 46px 14px 46px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #0e0d12;
    margin-top: 80px;
    margin-right: -124px;
    position: absolute;
    right: 455px;
    bottom: -82px;
      }

      #btn1_submit{
        padding: 14px 46px 14px 46px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #bdbac3;
    margin-top: 22px;
    position: absolute;
    left: 43px;
    text-decoration:none;



      }

      #btn_submit:hover {
        background-color: rgb(48, 78, 124);
        transition-duration: 0.8s;
        color: white;
      }
      #btn{
        display: flex;
        justify-content: space-around;
      }
      input{
        margin:15px 15px 15px 0;
        border:none;
        padding: 18px 122px 18px 20px;
        font-size: 15px;
         background-color:#f7f7f7;
         color:black;
        cursor: pointer;
        }

      input.active{
        background-color:black;
        color:white;
      }
      .btnmain{
        display:flex;
        justify-content:space-between;
      }
      
      #info_main{
display:flex;
flex-direction:column;
border:1px solid #9a9a9a;
width:586px;
padding:15px;
/* margin-left: 15px; */
      }

      #info_main1{
display:flex;
flex-direction:column;
border:1px solid #9a9a9a;
width:586px;
padding:15px;
/* margin-left: 15px; */
display:none;
      }

      #info_main2{
display:flex;
flex-direction:column;
border:1px solid #9a9a9a;
width:586px;
padding:15px;
/* margin-left: 15px; */
display:none;

      }
      .esse{
        display:flex;
justify-content:space-between;
margin:15px;
/* font-size:15px; */
      }

   .essee{
    font-size:17px;
}
      .esse2{
        display:flex;
justify-content:space-between;
margin:15px;
font-size:15px;
color:#9a9a9a;

      }
      .esse3{
        display:flex;
justify-content:start;
margin:15px;
      }
      .esse3 p{
        font-size:13px;
        
      }

      #checkbox{
        margin-right: 10px;
    margin-top: 2px;
      }
      #dan{
        margin:15px;
        font-size:16px;
      }
      .costing{
        display:flex;
        justify-content:center;
      }
      .costA{
        display:flex;
        flex-direction:column;
        background-color:black;
        padding:20px 50px 20px 50px;
        margin:0px;
        color:white;
      }
      
      .costB{
        display:flex;
        flex-direction:column;
        background-color:black;
        padding:20px 90px 20px 50px;
        margin:0px;
        color:white;

      }
      #cost2{
        display:none;
      }
      #cost3{
        display:none;
      }
      #cost2a{
        display:none;
      }
      #cost3a{
        display:none;
      }

    </style>
<div class="container">
      <div class="box1">
        <div id="box1">
        <img src="image/roof1.png" alt="" />
      </div>
      <div id="box2">
        <img src="image/roof2.png" alt="" />
      </div>
      <div id="box3">
        <img src="image/roof3.png" alt="" />
      </div>
      </div>
<div class="box2">
  <div class="costing">
    <div class="costA">
  <div id="cost1">
    <h3><?php echo($variable);?></div>
  <div id="cost2"><h3><?php echo($variable2);?> €</div>
  <div id="cost3"><h3><?php echo($variable1);?> €
  </div>
</h3><p>Yearly costs savings</p>
            </div>
            <div class="costB">
            <div id="cost1a">
    <h3><?php echo($variable_a);?></div>
  <div id="cost2a"><h3><?php echo($variable2a);?> €</div>
  <div id="cost3a"><h3><?php echo($variable1a);?> €
  </div><p>Total cost</p></div>
        </div>
        <p class="class1">Welk type zonnepaneel wil je installeren?</p>
        <p id="vul" class="class">
        Kies welke van onderstaande opties jouw voorkeur wegdraagt. Op basis daarvan passen we de prijs (en geschatte besparing) aan in het vak hierboven. In een volgende stap krijg je een compleet overzicht.
      </p>
  <div class="btnmain">
      <input type="button" value="Essential" id="btn_roof1" class="active" name="save" />
      <input type="Submit" value="Design" id="btn_roof2" class="" name="save" />
      <input type="Submit" value="Pro" id="btn_roof3" class="" name="save" />
      </div>
    <div  id= "info_main">
      <div class="esse"><p class="essee">Essential</p>
      <p class="">410W</p>
      </div>
      <div class="esse2">
      <p class="">Krijg waar voor je geld</p>
      <p class="">214W/m²</p>
      </div>
        <p id="dan" class="">
        Ons standaardmodel is energie- én kostenefficiënt. Het is geschikt voor alle soorten huizen: van rijwoningen tot bedrijfspanden en boerderijen.
      </p>
      <div class="esse3">
        <input  id = "checkbox" type="checkbox" required>
        <p>Is je huis ouder dan 10 jaar?</p>

      </div>
      </div>
    <div  id= "info_main1">
      <div class="esse"><p class="">Design</p>
      <p class="">405W</p>
      </div>
      <div class="esse2">
      <p class="">Stijl voor een mooie prijs</p>
      <p class="">211W/m²</p>
      </div>
        <p id="dan" class="">
        Met Design hoef je geen compromissen te sluiten op vlak van uitzicht of kwaliteit. Dit pakket bied je een hoge efficiëntie en een elegante en exclusieve look, dankzij de donkere kleur.
      </p>
      <div class="esse3">
        <input  id = "checkbox" type="checkbox" required>
        <p>Is je huis ouder dan 10 jaar?</p>
      </div>
      </div>
    <div  id= "info_main2">
      <div class="esse"><p class="">Pro</p>
      <p class="">415W</p>
      </div>
      <div class="esse2">
      <p class="">Pro met een reden</p>
      <p class="">234W/m²</p>
      </div>
        <p id="dan" class="">
        Pro is een stijlvol en betrouwbaar paneel met een hoog rendement. Het paneel is geproduceerd met innovatieve technologie en duurzaamheid in het achterhoofd. Met Pro krijg je een productgarantie dat hoge prestaties voor een lange tijd garandeert.


      </p>
      <div class="esse3">
        <input  id = "checkbox" type="checkbox" required>
        <p>Is je huis ouder dan 10 jaar?</p>
      </div>
      </div>
      <form action="testing5.php" method="get">
          <input type="hidden" value="<?php echo $_GET['cst_val'];?>" name="cst_val_test1">
           <input type="hidden" value="<?php echo $_GET['totalcost_val'];?>" name="totalcost_val_test2">
            <input type="hidden" value="<?php echo $_GET['select_land_area'];?>" name="select_land_squarearea">
          <div id="btn">
            <input type="Submit" value="Next" id="btn_submit" name="save" />
            </div>
          </form>
      <div>
        <!--<form action="testing3.php" method="get">-->
          <div id="btn">
            <!--<input type="Submit" value="Back" id="btn1_submit" name="save" />-->
             <a href="https://googlemap.tentoptoday.com/testing3.php" id="btn1_submit" >Back</a>
            </div>
          <!--</form>-->
        </div>
        </div>
        </div>
      </div>
    </div>
</body>
</html>