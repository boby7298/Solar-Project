<?php
include("connection.php");



$_SESSION['address']=$_GET['address'];
$_SESSION['latitude']=$_GET['latitude'];
$_SESSION['longitude']=$_GET['longitude'];

// echo $_SESSION['longitude'];
// echo "<pre>"; 
// print_r($_GET);
// echo "<pre>"; 


// echo $_GET['latitude'];
// echo "<pre>"; 
// echo $_GET['longitude']; 

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GOOGLE MAP</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  </head>
  <body>
    <script>

     var drawingManager;
      var all_overlays = [];
      function initMap() {
        // alert('shubham');
        var map = new google.maps.Map(document.getElementById("map"), {
          center: { lat: <?php echo $_GET['latitude']; ?>, lng: <?php echo $_GET['longitude']; ?> },
          zoom: 20,
          mapTypeId: google.maps.MapTypeId.SATELLITE,
          overviewMapControl: true,
          fullscreenControl: true,
          rotateControl: true,
          scaleControl: true,
          streetViewControl: true,
          mapTypeControl: true,
          noClear: false,
          tilt: 0,
        });

        // var marker = new google.maps.Marker({
        //   position: { lat: 51.186836, lng: 4.4362306 },
        //   map: map,
        //   title: "This is your property.",
        // });

        drawingManager = new google.maps.drawing.DrawingManager({
          drawingMode: google.maps.drawing.OverlayType.POLYGON,
          drawingControl: false,
          drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_CENTER,
            drawingModes: ["polygon"],
          },
          //markerOptions: {icon: 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png'},
          polygonOptions: {
            fillColor: "#72a2e7",
            strokeColor: "#1ac255",
            fillOpacity: 0.5,
            strokeWeight: 5,
            clickable: false,
            editable: true,
            zIndex: 1,
          },
        });
        drawingManager.setMap(map);
        function update_area() {
          area = 0;
          for (var i = 0; i < all_overlays.length; i++) {
            area += google.maps.geometry.spherical.computeArea(
              all_overlays[i].overlay.getPath()
              );
            }
            sq_feet = area * 10.76;
            alert(sq_feet);
          }
          google.maps.event.addListener(
          drawingManager,
          "overlaycomplete",
          function (event) {
                
            all_overlays.push(event);
            area=google.maps.geometry.spherical.computeArea(all_overlays[0].overlay.getPath());
            var areasq = Math.floor(area);
            var calculate = areasq * 10;
            var total_cost = areasq * 500;
            document.getElementById("print").innerHTML = areasq +" m² ";
            document.getElementById("print").style.display = "block";
            document.getElementById("undoDrawing").style.display = "block";
            document.getElementById("cstvaluee").value = calculate +" €";
            document.getElementById("totalcost").value = total_cost +" €";
            document.getElementById("select_area").value = areasq +" m² ";

          }
        );
        //Edit Shape
        $("#moveMap").click(function () {
          drawingManager.setDrawingMode(null);
          $("#yard_size").val(sq_feet);
        });
        //Trace Shape
        $("#editPoly").click(function () {
          drawingManager.setDrawingMode(
            google.maps.drawing.OverlayType.POLYGON
          );
        });
        //Delete All Shapes
        $("#undoDrawing").click(function () {
          for (var i = 0; i < all_overlays.length; i++) {
            all_overlays[i].overlay.setMap(null);
          }
          all_overlays = [];
          $("#yard_size").val(null);
          $("#print").hide();
        });
      }
      window.initMap = initMap;
//       $(document).ready(function(){
//       $("#btn_hide").click(function(){
//       $("#box1").toggle();
//   });

// });
    </script>
    <style>
      * {
        margin: 0;
        padding: 0;
      }
      html,
      body {
        font-family: 'Montserrat', sans-serif;
      }
      #map{
        height: 62%;
        width: 50%;
        /* display: none; */
        position: absolute;
        top: 20px;
        margin-left: 20px;
        margin-top: 100px;
        border-radius: 10px 0px 0px 10px;
      }
      .container {
        display: flex;
        justify-content: space-around;
        margin-top: 100px;
      }
      #box1 {
        width: 50%;
        height: 400px;
        border-radius: 10px 0 0 10px;
        position: absolute;
        left: 0px;
        margin-left: 20px;
         display: none;
      }
      img {
        width: 100%;
        height: 605px;
        border-radius: 10px 0px 0px 10px;
      }
      .box2 {
        display: flex;
        flex-direction: column;
        align-items: start;
        padding: 0px 0 0 30px;
        width: 50%;
        position: absolute;
        right: -59px;
      }
      .class {
        margin: 30px 30px 30px 0;
        width:520px;
        align-items: center;
      }
      .class1 {
        margin-top: 215px;
        font-size:28px;
      }
      input {
        padding: 15px 260px 15px 20px;
        font-size: 15px;
        border-radius: 20px;
        border: 1px solid black;
        cursor: pointer;
      }

      #vul {
        font-size: 15px;
      }
      #print{
        display: flex;
    justify-content: start;
    position: absolute;
    left: 320px;
    bottom: 255px;
    width: 166px;
    background-color:#FAF9F6;
    border:none;
    padding-left: 36px;
    padding-top: 20px;
    padding-bottom: 20px;
    border-radius: 5px;
    font-weight: 500;
    display:none;
    z-index: 1;

      }
      #print1{
        display: flex;
    justify-content: start;
    position: absolute;
    left: 110px;
    bottom: 0px;
    width: 200px;
    background-color:#FAF9F6;
    border:1px solid grey;
    padding-left: 36px;
    padding-top: 20px;
    padding-bottom: 20px;
    border-radius: 5px;
    font-weight: 500;
    display:none;

      }

      #btn_submit{
        padding: 14px 46px 14px 46px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #0e0d12;
    margin-top: 150px;
    margin-right: -124px;
    position: absolute;
    right: 500px;
    bottom: -195px;
      }

      #btn1_submit{
        padding: 14px 46px 14px 46px;
    border-radius: 40px;
    border: none;
    cursor: pointer;
    font-size: 15px;
    color: white;
    background-color: #bdbac3;
    margin-top: 150px;
    position: absolute;
    left: 46px;
    text-decoration: none;
      }

    #btn1_submit:hover{
background-color: rgb(48, 78, 124);
        transition-duration: 0.8s;
        color: white;
    } 

      

      #btn_submit:hover {
        background-color: rgb(48, 78, 124);
        transition-duration: 0.8s;
        color: white;
      }
      .controls{
        z-index: ;
      }
      #undoDrawing{
        display: flex;
    justify-content: start;
    position: absolute;
    left: 534px;
    bottom: 255px;
    width: 166px;
    background-color:#FAF9F6;
    border:none;
    padding-left: 36px;
    padding-top: 1px;
    padding-bottom: 20px;
    border-radius: 5px;
    font-weight: 500;
    display:none;
      }
      #moveMap{
        display:none;
      }
      #editPoly{
        display:none;
      }
      .fa-lg{
        font-size: 13px;
    position: absolute;
    left: 19px;
    top: 26px;
      }
      </style>
    <div class="container">
      <div id="box1">
        <img src="image/roof.png" alt="" />
      </div>
      
      <div class="box2">
        <p class="class1">Waar wil je de zonnepanelen plaatsen?</p>
        <p id="vul" class="class">
          Klik op elke hoek van het dak van je huis, of van het dakoppervlak waar je zonnepanelen wil leggen. Daarop kan je het aantal zonnepanelen zien. Verkeerd geklikt? Geen probleem: je kan altijd opnieuw beginnen.
        </p>
        <form action="testing3.php" method="get">
          <div id="btn">
          <input type="hidden" id="cstvaluee" name="cstvaluee">
          <input type="hidden" id="totalcost" name="totalcost">
          <input type="hidden" id="select_area" name="select_area">
            <input type="Submit" value="Next" id="btn_submit" name="save">
          </div>
        </form>
        <div>
            <div id="btn">
              <a href="https://googlemap.tentoptoday.com/" id="btn1_submit" >Back</a>
            </div>
        </div>
        </div>
      </div>
    </div>
  </div>
  <div id="print"><p></p></div>
  <!-- <div id="print1"><p></p></div> -->
  <div id="map"></div>
    <!-- <p id="print"></p> -->
    <div class="controls">
      <div class="span1 four"><a id="editPoly" class="tracing-control active" title="This is the drawing/tracing tool. Work with this tool to create your outlines."><i class="fa fa-lg fa-pencil icon-pencil icon-large"></i><br>Trace</a></div>
      <div class="span1 four"><a id="moveMap" class="tracing-control" title="Click here to move the map. Or click and drag when in Tracing mode."><i class="fa fa-lg fa-arrows icon-move icon-large"></i><br>Edit</a></div>
      <div class="span1 four"> <a id="undoDrawing" class="tracing-control" title="Did your tracing not turn out? Click here to undo your last outline."><i class="fa fa-lg fa-undo icon-undo icon-large"></i><br>Reset</a>
      </div>
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDAHc1YAJNk2m7ptFVLrdMCIX7YnC-p4sg&callback=initMap&libraries=drawing&v=weekly"
      defer
    ></script>
  </body>
</html>